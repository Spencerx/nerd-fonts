
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit a9cb48e9f4ac4a10333ab7559d97de5825148cc1
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Fri Jun 6 16:04:51 2025 +0200
        
            Merge pull request #1881 from ryanoasis/feature/slash-in-name
            
            font-patcher: Fix patching of fonts with slashes in name
